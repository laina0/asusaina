<html>
	<head>
		<link rel="stylesheet" href="<?php echo base_url() . 'assets/css/bootstrap.css'?>">
		<link rel="stylesheet" href="<?php echo base_url() . 'assets/css/datatable.css'?>">
		<script src="<?php echo base_url() . 'assets/js/jquery.js'?>"></script>
		<script src="<?php echo base_url() . 'assets/js/datatable.js';?>"></script>

		

	</head>
	<body>
		<div class='container'>
			<div class='list-group-item'>
				<h1> Liste</h1>
				<table id="myTable">
					<thead>
						<td> Nom </td>
						<td> Prenom </td>
						<td> Action </td>
					</thead>
					<tbody>
						test
						<?php
							foreach($allobject 	as $object) {
								echo "<tr>";
									echo "<td id='nom" . $object->id . "'>" . $object->nom . "</td>";
									echo "<td ondbclick='updatechamp(prenom" . $object->id . ")' id='prenom" . $object->id . "'>" . $object->prenom . "</td>";
									echo "<td id='button" . $object->id .  "' onclick='edit(" . $object->id . ")'> Update </td>";
								echo "</tr>";

							}
						?>
					</tbody>
				</table>
				<a class='btn btn-info' href='<?php echo base_url() . "index.php/accueil_controller/index" ?>'>
					Accueil
				</a>

			</div>
		</div>
	</body>
</html>

<script>
$(document).ready( function () {
    $('#myTable').DataTable();
} );

function edit(idpersonne) {
	var nom = $("#nom" + idpersonne).text();
	var prenom = $("#prenom" + idpersonne).text();
	
	$("#nom" + idpersonne).html("<input type='text' value='" + nom + "' id='inputnom" + idpersonne +"'>");
	$("#prenom" + idpersonne).html("<input type='text' value='" + prenom + "' id='inputprenom" + idpersonne +"'>");
	$("#button" + idpersonne).html("<input class='btn btn-info' type='submit' onclick='updatepersonne(" + idpersonne + ")' value='Save' id='inputbutton" + idpersonne +" '>");
	
}
function updatechamp(value) {
	alert(value);
}
function updatepersonne(idpersonne) {
	var nomprm = $("#inputnom" + idpersonne).val();
	var prenomprm = $("#inputprenom" + idpersonne).val();
	$.ajax(
			{
				type:"POST",
				url: "<?php echo base_url() . 'index.php/accueil_controller/updateFonctionAjax'; ?>",
				data:{ nom:nomprm, prenom:prenomprm, idpersonne : idpersonne},
				success:function(response)
				{
					if (response == "true") {
						$("#nom" + idpersonne).html(nomprm);
						$("#prenom" + idpersonne).html(prenomprm);
						$("#button" + idpersonne).html("Update");
					} else {
						alert("Erreur");
					}
				},
				error: function() 
				{
					alert("Invalide!");
				}
			}
		);
		
}
</script>













