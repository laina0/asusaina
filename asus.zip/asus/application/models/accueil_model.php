<?php
	class Accueil_model extends CI_Model {
		
		public function create($table, $objet) {
			$this->db->insert($table, $objet);
		}

		public function get_all($table, $limite){
			$query = $this->db->get($table, $limite);
			return $query->result();
		}
	}
?>
