<?php
	class Client_model extends CI_Model {
		public function auth($nom, $mdp){
			$hmdp = hash('sha256', $mdp, FALSE);
			$query = "select * from CLIENT where NOMCLIENT ='".$nom."' and MDP='".$hmdp."'";
			$query = $this->db->query($query);
			return $query->result();
		}

		public function insert($nom, $mdp){
			$hmdp = hash('sha256', $mdp, FALSE);
			$query = 'insert into CLIENT(NOMCLIENT, MDP) values('.$nom.', '.$hmdp.')';
			$query = $this->db->query($query);
			return $query->result();
		}
	}
?>
