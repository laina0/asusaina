<?php
	class Categorie_model extends CI_Model {
		
		public function create($table, $objet) {
			$this->db->insert($table, $objet);
		}

		public function get_all($table, $limite){
			$query = $this->db->get($table, $limite);
			return $query->result();
		}

		public function select(){
			$query = $this->db->get('CATEGORIE');
			return $query->result();
		}

		public function getbyid($idcateg){
			$query = 'select * from CATEGORIE where IDCATEGORIE ='.$idcateg;
			$query = $this->db->query($query);
			return $query->result();
		}

		public function insert($nomcategorie){
			$query = "insert into CATEGORIE(NOMCATEGORIE) values('".$nomcategorie."')";
			$query = $this->db->query($query);
			// return $query->result();
		}
	}
?>
