/*==============================================================*/
/* Nom de SGBD :  MySQL 5.0                                     */
/* Date de cr�ation :  06/05/2019 13:03:42                      */
/*==============================================================*/


drop table if exists CATEGORIE;

drop table if exists CLIENT;

drop table if exists PRODUIT;

/*==============================================================*/
/* Table : CATEGORIE                                            */
/*==============================================================*/
create table CATEGORIE
(
   IDCATEGORIE          int not null auto_increment,
   NOMCATEGORIE         varchar(20) not null,
   primary key (IDCATEGORIE)
);

/*==============================================================*/
/* Table : CLIENT                                               */
/*==============================================================*/
create table CLIENT
(
   IDCLIENT             int not null auto_increment,
   NOMCLIENT            varchar(50) not null,
   MDP                  varchar(20) not null,
   primary key (IDCLIENT)
);

/*==============================================================*/
/* Table : PRODUIT                                              */
/*==============================================================*/
create table PRODUIT
(
   IDPRODUIT            int not null auto_increment,
   IDCATEGORIE          int not null,
   NOMPRODUIT           varchar(20) not null,
   DESCRIPTION          text,
   IMAGE                varchar(50),
   primary key (IDPRODUIT)
);

alter table PRODUIT add constraint FK_DETAILPRODUIT foreign key (IDCATEGORIE)
      references CATEGORIE (IDCATEGORIE) on delete restrict on update restrict;

